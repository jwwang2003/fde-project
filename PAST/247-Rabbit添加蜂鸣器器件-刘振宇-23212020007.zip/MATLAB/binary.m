% 读取PNG图像文件
image = imread('name.png');

% 将图像转换为灰度图像
grayImage = rgb2gray(image);

% 二值化图像
binaryImage = imbinarize(grayImage);

% 将二值化矩阵按要求输出到txt文件
outputFile = 'output1.txt';
fid = fopen(outputFile, 'w');

[row, col] = size(binaryImage);
for c = 1:8:col
    for r = 1:row
        for i = 0:7
            fprintf(fid, '%d', binaryImage(r, c+i));
        end
        fprintf(fid, '\n');
    end
end

fclose(fid);