#pragma once
#ifndef Buzzer_COMPONENT_H
#define Buzzer_COMPONENT_H

#include <QLabel>
#include <QRadioButton>
#include <vector>

#include "Components/AbstractComponent.h"
#include "Components/ComponentMacro.h"
#include "Components/ComponentSettingsDialog.h"

namespace rabbit_App::component {

COMPONENT_CLASS_DECLARATION(Buzzer)


/// @brief BuzzerRawComponent class
/// This class implements the Buzzer component.
class BuzzerRawComponent : public AbstractRawComponent {
  Q_OBJECT

public:
  BuzzerRawComponent(QWidget *parent = nullptr);
  virtual ~BuzzerRawComponent();

  void reset() override;

  void processReadData(QQueue<uint64_t> &read_queue) override;
  uint64_t getWriteData() const override;

protected:
  void paintEvent(QPaintEvent *event) override;
  void initPorts() override;
  void playSound(float freq, float duration);
  int pop_cycle();

public slots:
  
  /// @brief Set the frequency of the Buzzer.

  void onSetFreq(float freq) { freq_ = freq; }

private:
  QLabel *buzzer_picture_;
  // bool is_on_ = false;
  float freq_ = 0.0f;
  int samp_cnt_ = 0;
  std::vector<int> cycle;
  int remain = 0;
};

/// @brief BuzzerSettingsDialog class
/// This class is used to display the Buzzer settings dialog.
/// Inherited from ActiveModeSettingsDialog and ColorSettingsDialog.
class BuzzerSettingsDialog : public ActiveModeSettingsDialog,
                          public ColorSettingsDialog {
  Q_OBJECT

public:
  BuzzerSettingsDialog(AbstractComponent *component, QWidget *parent = nullptr);
  virtual ~BuzzerSettingsDialog();

protected:
  void acceptDerivedClassSettings() override;

private:
  // ACTIVE_SETTING_DECLARATION_PRIVATE_MEMBER
  // COLOR_SETTING_DECLARATION_PRIVATE_MEMBER

}; // class BuzzerSettingsDialog

} // namespace rabbit_App::component

#endif // Buzzer_COMPONENT_H
