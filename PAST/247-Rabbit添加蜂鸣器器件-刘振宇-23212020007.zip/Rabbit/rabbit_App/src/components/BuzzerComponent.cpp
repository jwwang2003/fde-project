#include <QGradient>
#include <QLayout>
#include <QPainter>
#include <QRadialGradient>
#include <QSize>
#include <QThreadPool>
#include <alsa/asoundlib.h>
#include <cmath>
#include <climits>
#include <iostream>
#include <chrono>
#include <thread>


#include "Components/AbstractComponent.h"
#include "Components/ComponentMacro.h"
#include "Components/ComponentSettingsDialog.h"
#include "Components/BuzzerComponent.h"
#include "qgridlayout.h"
#include "qpainter.h"

using namespace rabbit_App::component;

BuzzerRawComponent::BuzzerRawComponent(QWidget *parent)
    : AbstractRawComponent(parent) {

  initPorts();

  setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
  buzzer_picture_ = new QLabel(this);
  buzzer_picture_->setPixmap(QPixmap(":/icons/icons/icons8-Buzzer-94.png"));

  buzzer_picture_->setScaledContents(true);
  buzzer_picture_->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);

  auto layout = new QHBoxLayout(this);
  layout->addWidget(buzzer_picture_);
  layout->setContentsMargins(0, 0, 0, 0);
  setLayout(layout);
}


BuzzerRawComponent::~BuzzerRawComponent() {}

void BuzzerRawComponent::reset() {
  // is_on_ = false;
  freq_ = 0.0f;
  update();
}

void BuzzerRawComponent::processReadData(QQueue<uint64_t> &read_queue) {
  if (read_queue.isEmpty()) {
    return;
  }
  int count = 0;
  int last = 0;
  int t_cnt = 0;
  for (auto value : read_queue) {
    auto buzzer_index = output_ports_[0].pin_index - 1;
    auto buzzer = (value >> buzzer_index) & 0x1;
    t_cnt++;
    if (buzzer == 1 && last == 0){
        count++;
        cycle.push_back(t_cnt);
        //std::cout << "in push " << t_cnt << std::endl;
        t_cnt = 0;
    }
    last = buzzer;
  }
  int ll = t_cnt + remain;
  if(ll > 98){
    int pnum = ll / 50;
    for(int i = 0; i < pnum; i++){
      cycle.push_back(50);
      //std::cout << "push " << 50 << std::endl;
    }
    remain = ll - pnum * 50;
  }
  else{
    cycle.push_back(t_cnt);
    //std::cout << "ex push " << t_cnt << std::endl;
  }
  samp_cnt_ += 1;
  if(samp_cnt_ >= 120){
    int sound_cycle = pop_cycle();
    if (sound_cycle == 0){
      sound_cycle = pop_cycle();
    }
    if (sound_cycle == 0){
      sound_cycle = pop_cycle();
    }
    //std::cout << "cycle" << sound_cycle << std::endl;
    auto freq = 9850 / static_cast<float>(sound_cycle);
    if(freq < 200){
      freq = 0;
    }
    onSetFreq(is_low_active_ ? 1.0f - freq : freq);
    //std::cout << "frequency: " << freq << std::endl;
    std::thread sound (&BuzzerRawComponent::playSound,this, freq, 0.45);
    sound.detach();
    ///std::cout << std::endl;
    samp_cnt_ -= 30;
  }
}

int BuzzerRawComponent::pop_cycle(){
  if(cycle.empty()){
    return 0;
  }
  int cc = cycle.front();
  int fnt = 0;
  for (auto it = cycle.begin(); it != cycle.end(); ++it){
    if(*it == *(it + 1) && *it == *(it + 2) && *it == *(it + 3) && *it == *(it + 4)){
      //std::cout << "cc:" << *it << std::endl;
      cc = *it;
      break;
    }
    else{
      fnt++;
    }
  }
  cycle.erase(cycle.begin(), cycle.begin() + fnt);

  int n = 0;
  int bubble = 0;
  for (auto it = cycle.begin(); it != cycle.end() && n * cc < 4800; ++it) {
    if(*it != cc ){
      //std::cout << "detect bubble..........." << *it << std::endl;
      if(*it + *(it + 1) == cc){
        n++;
        it += 1;
        bubble++;
        //std::cout << "bubble 1" << std::endl;
      }
      else if(*it + *(it + 1) + *(it + 2) == cc){
        n++;
        it += 2;
        bubble += 2;
        //std::cout << "bubble 2" << std::endl;
      }
      else if (*it + *(it + 1) + *(it + 2 ) + *(it + 3) == cc){
        n++;
        it += 3;
        bubble += 3;
        //std::cout << "bubble 3" << std::endl;
      }
      else{
        //std::cout << "*it + *(it + 1) = "<< *it + *(it + 1) << std::endl;
        //std::cout << "*it + *(it + 1) + *(it +2) = "<< *it + *(it + 1) + *(it +2) << std::endl;
        //std::cout << "*it + *(it + 1) + *(it +2 ) + *(it + 3) = "<< *it + *(it + 1) + *(it +2 ) + *(it + 3) << std::endl;
        break;
      }
    }
    else{
      n++;
    }
  }
  //std::cout << "n:" << n << std::endl;
  int sum = n * cc;
  int pop_num = 0;
  if(sum >= 4800){
    pop_num = 4800 / cc + bubble;
    //std::cout << "erase........................" << pop_num << std::endl;
    cycle.erase(cycle.begin(), cycle.begin() + pop_num);
  }
  else if(sum < 4800 && sum > 2450){
    pop_num = n + bubble;
    //std::cout << "erase........................" << pop_num << std::endl;
    cycle.erase(cycle.begin(), cycle.begin() + pop_num);
  }
  else{
    pop_num = n + bubble;
    //std::cout << "erase........................" << pop_num << std::endl;
    cycle.erase(cycle.begin(), cycle.begin() + pop_num);
    cc = 0;
  }
  return cc;
}

void BuzzerRawComponent::playSound(float freq, float duration){
      const unsigned int sampleRate = 48000; // 

    // 
    snd_pcm_t *pcmHandle;
    snd_pcm_open(&pcmHandle, "default", SND_PCM_STREAM_PLAYBACK, 0);

    
    snd_pcm_set_params(pcmHandle,
                       SND_PCM_FORMAT_S16_LE, 
                       SND_PCM_ACCESS_RW_INTERLEAVED, 
                       1, 
                       sampleRate, 
                       0, 
                       500000); 

    const size_t bufferSize = sampleRate * duration;
    short buffer[bufferSize];

    // 
    for (size_t i = 0; i < bufferSize; ++i) {
        double t = static_cast<double>(i) / sampleRate;
        double value = std::sin(2 * M_PI * freq * t);
        buffer[i] = static_cast<short>(value * SHRT_MAX / 2.0);
    }

    // 
    snd_pcm_writei(pcmHandle, buffer, bufferSize);

    // 
    snd_pcm_close(pcmHandle);
}


uint64_t BuzzerRawComponent::getWriteData() const { return 0; }

void BuzzerRawComponent::paintEvent(QPaintEvent *event) {}

void BuzzerRawComponent::initPorts() {
  appendPort(output_ports_, "Buzzer", ports::PortType::Output);
}

// void BuzzerRawComponent::onSwitchBuzzer(bool is_on) {
//   is_on_ = is_on;
// }

// BuzzerComponent::BuzzerComponent(QWidget *parent) : AbstractComponent(parent) {
//   raw_component_ = new BuzzerRawComponent(this);
//   layout()->addWidget(raw_component_);
// }

// BuzzerComponent::~BuzzerComponent() {}

// QSize BuzzerComponent::gridOccupation() const noexcept { return QSize(2, 2); }

// void BuzzerComponent::contextMenuEvent(QContextMenuEvent *event) {
//   AbstractComponent::contextMenuEvent(event);
// }

COMPONENT_CLASS_DEFINITION(Buzzer, 3, 3)

void BuzzerComponent::onSettingsBtnClicked() {
  auto settings_dialog = new BuzzerSettingsDialog(this, this);
  settings_dialog->exec();
  delete settings_dialog;
}
// void BuzzerComponent::setSettingsDialog() {
//   settings_dialog_ = new BuzzerSettingsDialog(this, this);
// }

BuzzerSettingsDialog::BuzzerSettingsDialog(AbstractComponent *component,
                                     QWidget *parent)
    : ComponentSettingsDialog(component, parent),
      ActiveModeSettingsDialog(component, parent),
      ColorSettingsDialog(component, parent) {

  // ACTIVE_SETTING_DEFINITION_CONSTRUCTOR
  // COLOR_SETTING_DEFINITION_CONSTRUCTOR
}

BuzzerSettingsDialog::~BuzzerSettingsDialog() {
  // color_map_.clear();
}

void BuzzerSettingsDialog::acceptDerivedClassSettings() {
  // ACTIVE_SETTING_DEFINITION_ACCEPT
  // COLOR_SETTING_DEFINITION_ACCEPT
  ActiveModeSettingsDialog::acceptDerivedClassSettings();
  ColorSettingsDialog::acceptDerivedClassSettings();
}