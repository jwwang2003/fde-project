之前上传的代码版本不对，重新上传了一次，并且添加了修改后的xmake.lua，否则无法成功编译。
因为使用了linux的C++第三方声音库，所以只能在linux上编译运行。
使用前需要先安装ALSA库：
sudo apt-get install libasound2-dev

